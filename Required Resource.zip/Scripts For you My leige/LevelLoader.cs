using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{
    public Animator transition;
    public string ToLoad;
    public int SCBI;

    void Start()
    {
        transition = GameObject.FindWithTag("Transition").GetComponent<Animator>();
        if (ToLoad == null)
        {
            ToLoad = "Menu";
        }
    }

    public void Load()
    {
        StartCoroutine("LoadLevel");

        if (PlayerPrefs.GetInt("LevelsReacheds") < SCBI)
        {
            PlayerPrefs.SetInt("LevelsReached", SCBI);
        }
    }

    IEnumerator LoadLevel()
    {
        transition.SetTrigger("Start");

        yield return new WaitForSeconds(1);

        SceneManager.LoadScene(ToLoad);
    }
}
