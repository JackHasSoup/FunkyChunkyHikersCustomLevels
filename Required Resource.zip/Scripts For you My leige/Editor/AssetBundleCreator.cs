using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

public class AssetBundleCreator
{
    [MenuItem("FCH/Export Map", priority = 0)]

    private static void BuildBundles()
    {
        AssetBundleBuild[] bundles = new AssetBundleBuild[]
        {
            new AssetBundleBuild()
            {
                assetBundleName = "Test",
                assetNames = new string[] {EditorSceneManager.GetActiveScene().path}
            }
        };

        BuildPipeline.BuildAssetBundles("Assets/AssetBundles", bundles, BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows64);
    }
}
