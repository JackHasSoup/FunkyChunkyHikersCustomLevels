using UnityEngine;

public class SpawnPosition : MonoBehaviour
{
    public Hiker hiker;
}

public enum Hiker
{
    Hiker_1, Hiker_2
}
